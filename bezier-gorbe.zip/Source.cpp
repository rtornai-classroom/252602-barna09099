﻿#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>
#include <iostream>
#include <cmath>

using namespace std;
using namespace glm;

enum eVertexArrayObject { VAOControlPoints, VAOCurveData, VAOCount };
enum eBufferObject { VBOControlPoints, VBOCurveData, BOCount };
enum eProgram { RenderingProgram, ProgramCount };
enum eTexture { NoTexture, TextureCount };

#include "common.cpp" 

// Az ablak címe
GLchar  windowTitle[] = "Bezier-gorbe Tiszai Barna YBL9K7";
GLint   dragged = -1;

vector<vec3> controlPoints = {
    vec3(-0.8f, -0.5f, 0.0f),
    vec3(-0.4f,  0.5f, 0.0f),
    vec3(0.4f,  0.5f, 0.0f),
    vec3(0.8f, -0.5f, 0.0f)
};
vector<vec3> curvePoints;
GLuint locationColor, locationIsPoint;

double Bernstein4(GLint i, GLfloat t) {
    switch (i) {
    case 0: return ((1.0 - t) * (1.0 - t) * (1.0 - t) * (1.0 - t));
    case 1: return (4.0 * t * (1.0 - t) * (1.0 - t) * (1.0 - t));
    case 2: return (6.0 * t * t * (1.0 - t) * (1.0 - t));
    case 3: return (4.0 * t * t * t * (1.0 - t));
    case 4: return (t * t * t * t);
    }
    return 0.0;
}

double Bernstein3(GLint i, GLfloat t) {
    switch (i) {
    case 0: return ((1.0 - t) * (1.0 - t) * (1.0 - t));
    case 1: return (3.0 * t * (1.0 - t) * (1.0 - t));
    case 2: return (3.0 * t * t * (1.0 - t));
    case 3: return (t * t * t);
    }
    return 0.0;
}

long long nCr(int n, int r) {
    if (r < 0 || r > n) return 0;
    if (r == 0 || r == n) return 1;
    long long res = 1;
    for (int i = 1; i <= r; i++) { res = res * (n - i + 1) / i; }
    return res;
}

double bernstein(int n, int i, double t) {
    return nCr(n, i) * std::pow(t, i) * std::pow(1.0 - t, n - i);
}

void updateCurve() {
    curvePoints.clear();
    int n = controlPoints.size() - 1;
    if (n < 0) return;
    for (int step = 0; step <= 250; step++) {
        GLfloat t = step / 250.0f;
        vec3 p(0.0f);
        for (int i = 0; i <= n; i++) {
            double b = (n == 3) ? Bernstein3(i, t) : (n == 4) ? Bernstein4(i, t) : bernstein(n, i, t);
            p += (float)(b)*controlPoints[i];
        }
        curvePoints.push_back(p);
    }
}

void updateBuffers() {
    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOControlPoints]);
    glBufferData(GL_ARRAY_BUFFER, controlPoints.size() * sizeof(vec3), controlPoints.data(), GL_DYNAMIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOCurveData]);
    glBufferData(GL_ARRAY_BUFFER, curvePoints.size() * sizeof(vec3), curvePoints.data(), GL_DYNAMIC_DRAW);
}

void initShaderProgram() {
    ShaderInfo shader_info[] = {
        { GL_VERTEX_SHADER,   "./vertexShader.glsl" },
        { GL_FRAGMENT_SHADER, "./fragmentShader.glsl" },
        { GL_NONE, nullptr }
    };
    program[RenderingProgram] = LoadShaders(shader_info);
    locationColor = glGetUniformLocation(program[RenderingProgram], "my_color");
    locationIsPoint = glGetUniformLocation(program[RenderingProgram], "isPoint");

    glBindVertexArray(VAO[VAOControlPoints]);
    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOControlPoints]);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

    glBindVertexArray(VAO[VAOCurveData]);
    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOCurveData]);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

    glEnable(GL_PROGRAM_POINT_SIZE);
    glEnable(GL_POINT_SPRITE);

    updateCurve();
    updateBuffers();
}

void display(GLFWwindow* window, double currentTime) {
    glClearColor(0.15f, 0.15f, 0.15f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    if (controlPoints.empty()) return;

    glUseProgram(program[RenderingProgram]);

    // 1. Poligon (Zöld)
    glUniform1i(locationIsPoint, 0);
    glUniform3f(locationColor, 0.0f, 1.0f, 0.0f);
    glBindVertexArray(VAO[VAOControlPoints]);
    glLineWidth(2.0f);
    glDrawArrays(GL_LINE_STRIP, 0, controlPoints.size());

    // 2. Görbe (Piros)
    glUniform1i(locationIsPoint, 0);
    glUniform3f(locationColor, 1.0f, 0.3f, 0.3f);
    glBindVertexArray(VAO[VAOCurveData]);
    glLineWidth(4.0f);
    glDrawArrays(GL_LINE_STRIP, 0, curvePoints.size());

    // 3. Pontok (Kék)
    glUniform1i(locationIsPoint, 1);
    glUniform3f(locationColor, 0.3f, 0.6f, 1.0f);
    glBindVertexArray(VAO[VAOControlPoints]);
    glDrawArrays(GL_POINTS, 0, controlPoints.size());
}

void framebufferSizeCallback(GLFWwindow* window, int width, int height) {
    windowWidth = glm::max(width, 1);
    windowHeight = glm::max(height, 1);
    glViewport(0, 0, windowWidth, windowHeight);
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if ((action == GLFW_PRESS) && (key == GLFW_KEY_ESCAPE)) glfwSetWindowShouldClose(window, GLFW_TRUE);
}

void cursorPosCallback(GLFWwindow* window, double xPos, double yPos) {
    if (dragged >= 0) {
        controlPoints[dragged].x = xPos * 2.0f / (GLdouble)windowWidth - 1.0f;
        controlPoints[dragged].y = ((GLdouble)windowHeight - yPos) * 2.0f / (GLdouble)windowHeight - 1.0f;
        updateCurve();
        updateBuffers();
    }
}

void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods) {
    double x, y; glfwGetCursorPos(window, &x, &y);
    vec3 m(x * 2.0f / (GLdouble)windowWidth - 1.0f, ((GLdouble)windowHeight - y) * 2.0f / (GLdouble)windowHeight - 1.0f, 0.0f);

    if (button == GLFW_MOUSE_BUTTON_LEFT) {
        if (action == GLFW_PRESS) {
            dragged = -1;
            for (int i = 0; i < controlPoints.size(); i++) {
                if (length(controlPoints[i] - m) < 0.05f) { dragged = i; break; }
            }
            if (dragged == -1) { controlPoints.push_back(m); updateCurve(); updateBuffers(); }
        }
        else { dragged = -1; }
    }
    else if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS) {
        for (int i = 0; i < controlPoints.size(); i++) {
            if (length(controlPoints[i] - m) < 0.05f) { controlPoints.erase(controlPoints.begin() + i); updateCurve(); updateBuffers(); break; }
        }
    }
}

int main(void) {
    init(4, 3, GLFW_OPENGL_COMPAT_PROFILE);
    glfwSetWindowSize(window, 800, 800);
    initShaderProgram();
    framebufferSizeCallback(window, 800, 800);

    while (!glfwWindowShouldClose(window)) {
        display(window, glfwGetTime());
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    cleanUpScene(EXIT_SUCCESS);
    return EXIT_SUCCESS;
}