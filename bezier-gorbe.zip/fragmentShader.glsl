#version 430

uniform vec3 my_color;
uniform int isPoint; 

out vec4 finalColor; 

void main()
{
    // Ha pontot rajzolunk (isPoint == 1), kerekítjük a formát!
    if (isPoint == 1) {
        vec2 circCoord = 2.0 * gl_PointCoord - 1.0;
        if (dot(circCoord, circCoord) > 1.0) {
            discard; 
        }
    }
    
    finalColor = vec4(my_color, 1.0);
}