﻿#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

// Shader beolvasó függvény
string loadShader(const char* fn) {
    string c;
    ifstream f(fn);
    if (!f.is_open()) {
        cout << "Hiba: Nem talalhato a shader fajl: " << fn << endl;
        return "";
    }
    string s;
    while (getline(f, s)) c += s + "\n";
    return c;
}

unsigned int prg, vao, vbo;
float korX = 0.0f, korY = 0.0f, vX = 0.0f, vY = 0.0f;
float vonalY = 0.0f;
float sug = 50.0f / 300.0f; // 50 pixel sugar
bool indult = false;

void init() {
    // Shaderek betoltese
    string vS = loadShader("vertex.glsl");
    string gS = loadShader("geometry.glsl");
    string fS = loadShader("fragment.glsl");

    const char* vK = vS.c_str(), * gK = gS.c_str(), * fK = fS.c_str();

    unsigned int v = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(v, 1, &vK, 0); glCompileShader(v);

    unsigned int g = glCreateShader(GL_GEOMETRY_SHADER);
    glShaderSource(g, 1, &gK, 0); glCompileShader(g);

    unsigned int f = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(f, 1, &fK, 0); glCompileShader(f);

    prg = glCreateProgram();
    glAttachShader(prg, v);
    glAttachShader(prg, g);
    glAttachShader(prg, f);
    glLinkProgram(prg);

    // Buffer keszites az egyetlen ponthoz
    float pont[] = { 0.0f, 0.0f, 0.0f };
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(pont), pont, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
}

void processInput(GLFWwindow* w) {
    // Vonal mozgatasa fel-le nyilakkal
    if (glfwGetKey(w, GLFW_KEY_UP) == GLFW_PRESS) vonalY += 0.01f;
    if (glfwGetKey(w, GLFW_KEY_DOWN) == GLFW_PRESS) vonalY -= 0.01f;

    // Inditas 'S' billentyure 25 fokos szogben
    if (glfwGetKey(w, GLFW_KEY_S) == GLFW_PRESS && !indult) {
        float alpha = 25.0f * 3.14159f / 180.0f;
        float sebesseg = 0.01f; // 10 pixel elmozdulas korul
        vX = cos(alpha) * sebesseg;
        vY = sin(alpha) * sebesseg;
        indult = true;
    }
}

int main() {
    if (!glfwInit()) return -1;

    // 600x600-as ablak letrehozasa
    GLFWwindow* w = glfwCreateWindow(600, 600, "Grafika Beadando - Final", NULL, NULL);
    if (!w) { glfwTerminate(); return -1; }

    glfwMakeContextCurrent(w);
    glewInit();
    glfwSwapInterval(1); // V-Sync bekapcsolasa a normalis sebesseghez

    init();

    while (!glfwWindowShouldClose(w)) {
        processInput(w);

        // 1. Sarga hatter beallitasa
        glClearColor(1.0f, 1.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        glUseProgram(prg);
        glBindVertexArray(vao);

        // 2. Fizika: Mozgas es visszapattanas a szelekrol
        if (indult) {
            korX += vX;
            korY += vY;

            // X iranyú pattanás
            if (korX + sug > 1.0f || korX - sug < -1.0f) vX *= -1.0f;
            // Y iranyú pattanás
            if (korY + sug > 1.0f || korY - sug < -1.0f) vY *= -1.0f;
        }

        // 3. Metszesvizsgalat (Körlap és a kék szakasz között)
        // A szakasz [-1/3, 1/3] kozott van X-ben, es vonalY magassagban
        bool metsz = (abs(korX) < (1.0f / 3.0f) + sug && abs(korY - vonalY) < sug);

        // 4. Uniformok kuldese a shadereknek
        glUniform1i(glGetUniformLocation(prg, "metszesbenVan"), metsz);

        // --- KEK SZAKASZ RAJZOLASA ---
        glUniform1i(glGetUniformLocation(prg, "alakzatTipus"), 1);
        glUniform1f(glGetUniformLocation(prg, "akadalY"), vonalY);
        glDrawArrays(GL_POINTS, 0, 1);

        // --- KOR RAJZOLASA ---
        glUniform1i(glGetUniformLocation(prg, "alakzatTipus"), 0);
        glUniform2f(glGetUniformLocation(prg, "objektumHelye"), korX, korY);
        glUniform2f(glGetUniformLocation(prg, "korKozep"), korX, korY);
        glDrawArrays(GL_POINTS, 0, 1);

        glfwSwapBuffers(w);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}