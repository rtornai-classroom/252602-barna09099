#version 430 core
out vec4 kimenetiSzin;
in vec2 fragPos;

uniform int alakzatTipus;
uniform vec2 korKozep;
uniform bool metszesbenVan;

void main() {
    if (alakzatTipus == 1) {
        kimenetiSzin = vec4(0.0, 0.0, 1.0, 1.0); // Kék szakasz
    } else {
        float r = 50.0 / 300.0;
        float d = distance(fragPos, korKozep);
        float t = clamp(d / r, 0.0, 1.0); // 0 a közepén, 1 a szélén
        
        vec3 belsoSzin = metszesbenVan ? vec4(1.0, 0.0, 0.0, 1.0).rgb : vec4(0.0, 1.0, 0.0, 1.0).rgb;
        vec3 kulsoSzin = metszesbenVan ? vec4(0.0, 1.0, 0.0, 1.0).rgb : vec4(1.0, 0.0, 0.0, 1.0).rgb;
        
        kimenetiSzin = vec4(mix(belsoSzin, kulsoSzin, t), 1.0);
    }
}