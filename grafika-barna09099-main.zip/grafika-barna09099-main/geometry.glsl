#version 430 core
layout (points) in;
layout (triangle_strip, max_vertices = 110) out;

uniform int alakzatTipus; 
uniform vec2 objektumHelye;
uniform float akadalY;

out vec2 fragPos; // Átadjuk a fragment shadernek a pixel helyét

void main() {
    if (alakzatTipus == 1) { // KÉK SZAKASZ (Harmad szélesség = 2.0/3.0, Vastagság = 3 pixel)
        float szel = 1.0 / 3.0; 
        float vastag = 0.01; // kb 3 pixel 600-as ablaknál
        gl_Position = vec4(-szel, akadalY - vastag, 0.0, 1.0); fragPos = gl_Position.xy; EmitVertex();
        gl_Position = vec4(-szel, akadalY + vastag, 0.0, 1.0); fragPos = gl_Position.xy; EmitVertex();
        gl_Position = vec4(szel, akadalY - vastag, 0.0, 1.0); fragPos = gl_Position.xy; EmitVertex();
        gl_Position = vec4(szel, akadalY + vastag, 0.0, 1.0); fragPos = gl_Position.xy; EmitVertex();
        EndPrimitive();
    } else { // KÖR
        float r = 50.0 / 300.0; // 50 pixel sugarú (a 300 a fél ablak)
        for(int k = 0; k <= 50; k++) {
            float szog = float(k) * 2.0 * 3.14159 / 50.0;
            gl_Position = vec4(objektumHelye, 0.0, 1.0); fragPos = gl_Position.xy; EmitVertex();
            vec2 perem = objektumHelye + vec2(cos(szog)*r, sin(szog)*r);
            gl_Position = vec4(perem, 0.0, 1.0); fragPos = gl_Position.xy; EmitVertex();
        }
        EndPrimitive();
    }
}