#version 430 core
layout (location = 0) in vec3 bejovoPont;
void main() {
    gl_Position = vec4(bejovoPont, 1.0);
}