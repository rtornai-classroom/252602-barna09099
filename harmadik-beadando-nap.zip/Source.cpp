﻿#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_inverse.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

// Textúra betöltő
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

using namespace std;

static int WIN_WIDTH = 800;
static int WIN_HEIGHT = 800;
char WIN_TITLE[] = "Tiszai Barna - YBL9K7";

GLuint VBO, VAO, sphereVBO, sphereVAO;
GLuint renderingProgram;
GLuint sunTextureID;

// Kamera paraméterek
float r = 8.0f;
float camTheta = 0.0f;
float camZ = 0.0f;
float fov = 55.0f;
glm::vec3 UP = glm::vec3(0.0f, 0.0f, 1.0f);
glm::vec3 KameraHelyzet;

// Bónusz változók
bool lightingEnabled = true;
glm::vec3 lightColor(1.0f, 0.8f, 0.2f); // Sárgás napfény
int sphereVertexCount = 0;

struct Vertex {
    glm::vec3 Position;
    glm::vec3 Normal;
    glm::vec2 TexCoords;
};

std::vector<Vertex> cubeVertices;
std::vector<glm::vec3> cubePositions = {
    glm::vec3(0.0f, 0.0f, 0.0f),
    glm::vec3(0.0f, 0.0f, 2.0f),
    glm::vec3(0.0f, 0.0f, -2.0f)
};

// Textúra betöltő függvény
GLuint loadTexture(char const* path) {
    GLuint textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data) {
        GLenum format = (nrComponents == 4) ? GL_RGBA : GL_RGB;
        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        stbi_image_free(data);
    }
    else {
        cout << "Hiba a textura betoltesekor: " << path << endl;
        stbi_image_free(data);
    }
    return textureID;
}

// 36 pontos kockagenerátor normálvektorokkal
void generateCube() {
    float pts[] = {
        // Pozíció (3),        Normál (3),         UV (2)
        // Hátsó lap
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
        // Első lap
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
        // Bal lap
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        // Jobb lap
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
         // Alsó lap
         -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
          0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
          0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
          0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
         -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
         -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
         // Felső lap
         -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
          0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
          0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
          0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
         -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
         -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f
    };
    for (int i = 0; i < 36; i++) {
        Vertex v;
        v.Position = glm::vec3(pts[i * 8], pts[i * 8 + 1], pts[i * 8 + 2]);
        v.Normal = glm::vec3(pts[i * 8 + 3], pts[i * 8 + 4], pts[i * 8 + 5]);
        v.TexCoords = glm::vec2(pts[i * 8 + 6], pts[i * 8 + 7]);
        cubeVertices.push_back(v);
    }
}

// Gömb generátor a Nap számára
std::vector<Vertex> sphereVertices;
void generateSphere(float radius, int sectorCount, int stackCount) {
    float x, y, z, xy;
    float nx, ny, nz, lengthInv = 1.0f / radius;
    float s, t;

    float sectorStep = 2 * glm::pi<float>() / sectorCount;
    float stackStep = glm::pi<float>() / stackCount;
    float sectorAngle, stackAngle;

    std::vector<Vertex> tempVertices;
    for (int i = 0; i <= stackCount; ++i) {
        stackAngle = glm::pi<float>() / 2 - i * stackStep;
        xy = radius * cosf(stackAngle);
        z = radius * sinf(stackAngle);

        for (int j = 0; j <= sectorCount; ++j) {
            sectorAngle = j * sectorStep;
            x = xy * cosf(sectorAngle);
            y = xy * sinf(sectorAngle);
            nx = x * lengthInv; ny = y * lengthInv; nz = z * lengthInv;
            s = (float)j / sectorCount; t = (float)i / stackCount;
            tempVertices.push_back({ glm::vec3(x, y, z), glm::vec3(nx, ny, nz), glm::vec2(s, t) });
        }
    }

    for (int i = 0; i < stackCount; ++i) {
        int k1 = i * (sectorCount + 1);
        int k2 = k1 + sectorCount + 1;
        for (int j = 0; j < sectorCount; ++j, ++k1, ++k2) {
            if (i != 0) {
                sphereVertices.push_back(tempVertices[k1]);
                sphereVertices.push_back(tempVertices[k2]);
                sphereVertices.push_back(tempVertices[k1 + 1]);
            }
            if (i != (stackCount - 1)) {
                sphereVertices.push_back(tempVertices[k1 + 1]);
                sphereVertices.push_back(tempVertices[k2]);
                sphereVertices.push_back(tempVertices[k2 + 1]);
            }
        }
    }
    sphereVertexCount = sphereVertices.size();
}

string readShaderSource(const char* filePath) {
    string content;
    ifstream fileStream(filePath, ios::in);
    if (!fileStream.is_open()) return "";
    string line = "";
    while (getline(fileStream, line)) content.append(line + "\n");
    fileStream.close();
    return content;
}

GLuint createShaderProgram(const char* fragmentFile) {
    GLuint vShader = glCreateShader(GL_VERTEX_SHADER);
    GLuint fShader = glCreateShader(GL_FRAGMENT_SHADER);
    string vertStr = readShaderSource("vertexShader.glsl");
    string fragStr = readShaderSource(fragmentFile);
    const char* vSrc = vertStr.c_str(); const char* fSrc = fragStr.c_str();

    glShaderSource(vShader, 1, &vSrc, NULL);
    glShaderSource(fShader, 1, &fSrc, NULL);
    glCompileShader(vShader); glCompileShader(fShader);

    GLuint prog = glCreateProgram();
    glAttachShader(prog, vShader); glAttachShader(prog, fShader);
    glLinkProgram(prog);
    glDeleteShader(vShader); glDeleteShader(fShader);
    return prog;
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (action == GLFW_PRESS || action == GLFW_REPEAT) {
        switch (key) {
        case GLFW_KEY_LEFT:  camTheta -= 5.0f; break;
        case GLFW_KEY_RIGHT: camTheta += 5.0f; break;
        case GLFW_KEY_UP:    camZ += 0.5f;     break;
        case GLFW_KEY_DOWN:  camZ -= 0.5f;     break;
        case GLFW_KEY_L:     lightingEnabled = !lightingEnabled; break; // Világítás kapcsoló
        }
    }
}

void init(GLFWwindow* window) {
    renderingProgram = createShaderProgram("fragmentShader.glsl");

    generateCube();
    generateSphere(0.25f, 36, 18); // d = 0.5 -> r = 0.25

    // Nap textúra betöltése (Cseréld ki a fájlnevet a sajátodra!)
    sunTextureID = loadTexture("sun.jpg");

    // Kockák Bufferei
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, cubeVertices.size() * sizeof(Vertex), cubeVertices.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, Normal));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, TexCoords));
    glEnableVertexAttribArray(2);

    // Gömb (Nap) Bufferei
    glGenVertexArrays(1, &sphereVAO);
    glGenBuffers(1, &sphereVBO);
    glBindVertexArray(sphereVAO);
    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER, sphereVertices.size() * sizeof(Vertex), sphereVertices.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, Normal));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, TexCoords));
    glEnableVertexAttribArray(2);
}

void display(GLFWwindow* window, double currentTime) {
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);

    glUseProgram(renderingProgram);

    // Fény mozgatása körpályán (z=0, sugár=2*r)
    float time = (float)currentTime;
    glm::vec3 lightPos(2.0f * r * cos(time), 2.0f * r * sin(time), 0.0f);

    // Kamera pozició frissítése
    KameraHelyzet.x = r * cos(glm::radians(camTheta));
    KameraHelyzet.y = r * sin(glm::radians(camTheta));
    KameraHelyzet.z = camZ;

    glm::mat4 view = glm::lookAt(KameraHelyzet, glm::vec3(0.0f, 0.0f, 0.0f), UP);
    glm::mat4 projection = glm::perspective(glm::radians(fov), (float)WIN_WIDTH / WIN_HEIGHT, 0.1f, 100.0f);

    GLuint modelLoc = glGetUniformLocation(renderingProgram, "model");

    // Globális uniformok átküldése
    glUniformMatrix4fv(glGetUniformLocation(renderingProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(glGetUniformLocation(renderingProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
    glUniform3fv(glGetUniformLocation(renderingProgram, "lightPos"), 1, glm::value_ptr(lightPos));
    glUniform3fv(glGetUniformLocation(renderingProgram, "lightColor"), 1, glm::value_ptr(lightColor));
    glUniform1i(glGetUniformLocation(renderingProgram, "lightingEnabled"), lightingEnabled);

    // --- KOCKÁK RAJZOLÁSA (Fehér anyag, kapják a fényt) ---
    glBindVertexArray(VAO);
    glUniform1i(glGetUniformLocation(renderingProgram, "isLightSource"), false);
    glUniform1i(glGetUniformLocation(renderingProgram, "hasTexture"), false);
    glUniform3f(glGetUniformLocation(renderingProgram, "myColor"), 1.0f, 1.0f, 1.0f);

    for (auto pos : cubePositions) {
        glm::mat4 model = glm::translate(glm::mat4(1.0f), pos);
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glDrawArrays(GL_TRIANGLES, 0, 36);
    }

    // --- NAP RAJZOLÁSA (Sárga fény, van textúra, fényt bocsát ki) ---
    glBindVertexArray(sphereVAO);
    glUniform1i(glGetUniformLocation(renderingProgram, "isLightSource"), true);
    glUniform1i(glGetUniformLocation(renderingProgram, "hasTexture"), true);
    glUniform3fv(glGetUniformLocation(renderingProgram, "myColor"), 1, glm::value_ptr(lightColor));

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, sunTextureID);
    glUniform1i(glGetUniformLocation(renderingProgram, "sunTexture"), 0);

    glm::mat4 sunModel = glm::translate(glm::mat4(1.0f), lightPos);
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(sunModel));
    glDrawArrays(GL_TRIANGLES, 0, sphereVertexCount);
}

int main(void) {
    if (!glfwInit()) exit(EXIT_FAILURE);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    GLFWwindow* window = glfwCreateWindow(WIN_WIDTH, WIN_HEIGHT, WIN_TITLE, NULL, NULL);
    glfwMakeContextCurrent(window);
    glfwSetKeyCallback(window, keyCallback);
    if (glewInit() != GLEW_OK) exit(EXIT_FAILURE);

    init(window);
    while (!glfwWindowShouldClose(window)) {
        display(window, glfwGetTime());
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteVertexArrays(1, &sphereVAO);
    glDeleteBuffers(1, &sphereVBO);
    glDeleteProgram(renderingProgram);
    glfwTerminate();
    return 0;
}