#version 430

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoords;

out vec4 color;

uniform vec3 myColor;
uniform vec3 lightPos;
uniform vec3 lightColor;

uniform bool isLightSource;    
uniform bool lightingEnabled;  
uniform bool hasTexture;       
uniform sampler2D sunTexture;

void main(void)
{
    vec3 objectColor = myColor;
    if (hasTexture) {
        objectColor = texture(sunTexture, TexCoords).rgb;
    }

    // Ha ez maga a Nap, vagy ki van kapcsolva a fény
    if (isLightSource || !lightingEnabled) {
        color = vec4(objectColor, 1.0);
    } 
    else {
        // Diffúz fény számítása
        vec3 norm = normalize(Normal);
        vec3 lightDir = normalize(lightPos - FragPos);
        
        float diff = max(dot(norm, lightDir), 0.0);
        vec3 diffuse = diff * lightColor;
        
        // Pici alapfény, hogy ne legyen koromfekete az árnyék
        vec3 ambient = 0.15 * lightColor;

        vec3 result = (ambient + diffuse) * objectColor;
        color = vec4(result, 1.0);
    }
}